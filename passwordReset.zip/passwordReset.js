exports.passwordReset = function (event, context){ console.log('new lambda function generated'); }
